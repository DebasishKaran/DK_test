import {TeplateRef, ViewChild} from '@angular/core';
import {Component, OnInit} from '@angular/core';
import {Study} from './study.model';
import {StudyService} from './app.service';
import {Headers, Response} from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/Rx';
@Component({ selector: 'app-data', templateUrl: './app/app.component.html' })
 
export class AppComponent implements OnInit {
    //1. Template Ref types 
    @ViewChild('readOnlyTemplate') readOnlyTemplate: TemplateRef<any>;
    @ViewChild('editTemplate') editTemplate: TemplateRef<any>;
    //2. Other Variables
    message: string;
    study: Study;
    selstdy: Study;
    studys: Array<Study>;
    isNewRecord: boolean;
    statusMessage: string;
    //3. Constructor injected with the Service Dependency
    constructor(private serv: StudyService) {
        this.studys = new Array<Study>();
        this.message = 'Study Management';
    }
    //4. Load all Studys
    ngOnInit() {
        this.loadStudy();
    }
 
    private loadStudy() {
        this
            .serv
            .getStudy()
            .subscribe((resp: Response) => {
                this.studys = resp.json();
                //console.log(JSON.stringify(resp.json()));    
            });
    }
    //5. Add Study
 
    addStudy() {
        this.selstdy = new Study('','', '','');
        this
            .studys
            .push(this.selstdy);
        this.isNewRecord = true;
        //return this.editTemplate;
    }
 
    //6. Edit Study
    editStudy(stdy: Study) {
        this.selstdy = stdy;
    }
    //7. Load either Read-Only Tstdylate or EditTstdylate
    loadTemplate(stdy: Study) {
        if (this.selstdy && this.study.StudyName == stdy.StudyName) {
            return this.editTemplate;
        } else {
            return this.readOnlyTemplate;
        }
         
 
    }
    //8. Save Study
    saveStudy() {
        if (this.isNewRecord) {
            //add a new Study
            this.serv.addStudy(this.selstdy).subscribe((resp: Response) => {
                this.study = resp.json(),
                    this.statusMessage = 'Record Added Successfully.',
                    this.loadStudy();
            });
            this.isNewRecord = false;
            this.selstdy = null;
 
        } else {
            //edit the record
            this.serv.updateStudy(this.selstdy._id, this.selstdy).subscribe((resp: Response) => {
                this.statusMessage = 'Record Updated Successfully.',
                    this.loadStudy();
            });
            this.selstdy = null;
 
        }
    }
    //9. Cancel edit
    cancel() {
        this.selstdy = null;
    }
    //10 Delete Study
    deleteStudy(stdy: Study) {
        this.serv.deleteStudy(stdy._id).subscribe((resp: Response) => {
            this.statusMessage = 'Record Deleted Successfully.',
                this.loadStudy();
        });
 
    }
}
