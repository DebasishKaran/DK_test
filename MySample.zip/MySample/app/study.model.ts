export class Study {
    constructor(
        public _id: string,
        public StudyName: string,
        public ProjectName: string,
        public PUID: string
        ) { }
}
