library(ggplot2)
View(mtcars)
#scatterplot
ggplot(mtcars, mapping=aes(x = drat, y = mpg)) +
  geom_point()

#scatterplot with group
ggplot(mtcars, aes(x = mpg, y = drat)) +
  geom_point(aes(color = factor(gear)))

#change axis
ggplot(mtcars, aes(x = log(mpg), y = log(drat))) +
       geom_point(aes(col = factor(gear)))

#Scatter plot with fitted values
my_graph <- ggplot(mtcars, aes(x = log(mpg), y = log(drat))) +
  geom_point(aes(color = factor(gear))) +
  stat_smooth(method = "lm",
              col = "#C42126",
              se = FALSE,
              size = 1)
my_graph

#Rename x-axis and y-axis
my_graph +
  labs(
    x = "Drat definition",
    y = "Mile per hours",
    color = "Gear",
    title = "Relation between Mile per hours and drat",
    subtitle = "Relationship break down by gear class",
    caption = "Authors own computation"
  )


#control the scales
my_graph +
  scale_x_continuous(breaks = seq(1, 3.6, by = 0.2)) +
  scale_y_continuous(breaks = seq(1, 1.6, by = 0.1)) +
  labs(
    x = "Drat definition",
    y = "Mile per hours",
    color = "Gear",
    title = "Relation between Mile per hours and drat",
    subtitle = "Relationship break down by gear class",
    caption = "Authors own computation"
  )

#adding theme
my_graph +
  theme_bw() +
  labs(
    x = "Drat definition, in log",
    y = "Mile per hours, in log",
    color = "Gear",
    title = "Relation between Mile per hours and drat",
    subtitle = "Relationship break down by gear class",
    caption = "Authors own computation"
  )
#saving plot image in hard disk
directory <-getwd()
directory
ggsave("my_fantastic_plot.png")

#open the directory
# Run this code to create the function
open_folder <- function(dir) {
  if (.Platform['OS.type'] == "windows") {
    shell.exec(dir)
  } else {
    system(paste(Sys.getenv("R_BROWSER"), dir))
  }
}

# Call the
#function to open the folder open_folder(directory)

open_folder(directory)

