#Require the package so you can use it
require("httr")
install.packages("jsonlite")

#Require the package so you can use it
require("jsonlite")

username <- "Paste_API_Username_Here"
password <- "Paste_API_Password_Here"

base <- "https://api.intrinio.com/"
endpoint <- "prices"
stock <- "AAPL"

call1 <- paste(base,endpoint,"?","ticker","=", stock, sep="")
Call1