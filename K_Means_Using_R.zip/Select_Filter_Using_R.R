library(dplyr) 
PATH <- "https://raw.githubusercontent.com/thomaspernet/data_csv_r/master/data/travel_times.csv"
df <- read.csv(PATH)
glimpse(df)

#select()
#- `select(df, A, B ,C)`: Select the variables A, B and C from df dataset.
#- `select(df, A:C)`: Select all variables from A to C from df dataset.
#- `select(df, -C)`: Exclude C from the dataset from df dataset.	
step_1_df <- select(df, -Comments)
dim(df)

#filter
select_home <- filter(df, GoingTo == "Home")
dim(select_home)
#multiple filter
select_home_wed <- filter(df, GoingTo == "Home" & DayOfWeek == "Wednesday")
dim(select_home_wed)

#Pipeline
# Create the data frame filter_home_wed.It will be the object return at the end of the pipeline
filter_home_wed <-  #Step 1
  read.csv(PATH) %>%   #Step 2
  select(GoingTo, DayOfWeek) %>% 
    #Step 3
  filter(GoingTo == "Home",DayOfWeek == "Wednesday")

#arrange

arrange_distance <-  #Step 1
  read.csv(PATH) %>%   #Step 2
  select(GoingTo, Distance) %>%
  arrange(desc(Distance))
  