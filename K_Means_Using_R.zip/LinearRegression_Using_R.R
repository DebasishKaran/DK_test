library(ggplot2)
path <- 'https://raw.githubusercontent.com/thomaspernet/data_csv_r/master/data/women.csv'
df <-read.csv(path)
ggplot(df,aes(x=height, y =  weight))+
  geom_point()

beta <- cov(df$height, df$weight) / var (df$height)
beta

alpha <- mean(df$weight) - beta * mean(df$height)
alpha

#Continuous variables
library(dplyr)
df <- mtcars %>%
  select(-c(am, vs, cyl, gear, carb))
glimpse(df)

model <- mpg~ disp + hp + drat + wt
fit <- lm(model, df)
fit
summary(fit)
anova(fit)

par(mfrow=(2,2))
plot(fit)

df <- mtcars %>%
  mutate(cyl = factor(cyl),
         vs = factor(vs),
         am = factor(am),
         gear = factor(gear),
         carb = factor(carb))
summary(lm(model, df))

#Stepwise regression
library(GGally)
df <- mtcars %>%
  select(-c(am, vs, cyl, gear, carb))
ggscatmat(df, columns = 1: ncol(df))

library(olsrr)
model <- mpg~.
fit <- lm(model, df)
test <- ols_step_all_possible(fit)
plot(test)