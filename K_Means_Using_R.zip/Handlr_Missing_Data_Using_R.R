PATH <- "https://raw.githubusercontent.com/thomaspernet/data_csv_r/master/data/titanic_csv.csv"
df_titanic <- read.csv(PATH, sep=",")
list_na <- colnames(df_titanic)[apply(df_titanic,2,anyNA)]
list_na

library(dplyr)
# Exclude the missing observations
df_titanic_drop <-df_titanic %>% na.omit()		
dim(df_titanic_drop)

# Create mean
average_missing <- apply(df_titanic[,colnames(df_titanic) %in% list_na],
                         2,
                         mean,
                         na.rm = TRUE)

average_missing

# Create a new variable with the mean and median
df_titanic_replace <- df_titanic %>%
  mutate(replace_mean_age  = ifelse(is.na(age), average_missing[1], age),
         replace_mean_fare = ifelse(is.na(fare), average_missing[2], fare))

#check
sum(is.na(df_titanic_replace$age))
sum(is.na(df_titanic_replace$replace_mean_age))

# We can replace the missing observations with the median as well.
median_missing <- apply(df_titanic[,colnames(df_titanic) %in% list_na],
                        2,
                        median,
                        na.rm =  TRUE)
df_titanic_replace <- df_titanic %>%
  mutate(replace_median_age  = ifelse(is.na(age), median_missing[1], age), 
         replace_median_fare = ifelse(is.na(fare), median_missing[2], fare))
head(df_titanic_replace)

# Quick code to replace missing values with the mean
df_titanic_impute_mean <- data.frame(
  sapply(
    df_titanic,
    function(x) ifelse(is.na(x),
                       mean(x, na.rm = TRUE),
                       x)))
