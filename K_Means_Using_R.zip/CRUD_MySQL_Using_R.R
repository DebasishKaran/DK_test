#install.packages("RMySQL")
library(RMySQL)

#Connecting to MySQL:
#  Once the RMySQL library is installed create a database connection object.

mydb = dbConnect(MySQL(), user='root', password='root', dbname='setupsmart', host='127.0.0.1')

#Listing Tables and Fields:
#  Now that a connection has been made we list the tables and fields in the database we connected to.

dbListTables(mydb)

#This will return a list of the tables in our connection. 

dbListFields(mydb, 'phases')

#This will return a list of the fields in some_table.

#Running Queries:
#  Queries can be run using the dbSendQuery function.

#Retrieving data from MySQL:
#  To retrieve data from the database we need to save a results set object.

rs = dbSendQuery(mydb, "select * from phases")

#I believe that the results of this query remain on the MySQL server, to access the results in R we need to use the fetch function.

data = fetch(rs, n=-1)

#This saves the results of the query as a data frame object. The n in the function specifies the number of records to retrieve, using n=-1 retrieves all pending records.

#Making tables:
#  We can create tables in the database using R dataframes.

newPhase <- data.frame(
  
  Phase_Name = "Phase IV",
  Is_Active = "Y"
)

#dbSendQuery(mydb,newPhase)

dbWriteTable(mydb, name = "phases", value=newPhase, row.names=FALSE, append=TRUE)
#dbReadTable(mydb,"phases2")
#dbSendQuery(mydb,newPhase)

#update 
#dbSendQuery(mydb,"UPDATE phases SET Phase_Name='Phase V' where Phase_Name ='Phase IV'")

#delete
#dbSendQuery(mydb,"Delete from phases where Phase_Name ='Phase V'")



conn <- mydb
dbSendQuery(conn, 'DROP TABLE IF EXISTS Cars')
dbSendQuery(conn, 'CREATE TABLE Cars(Id INTEGER PRIMARY KEY, Name VARCHAR(20), Price INT)')
dbSendQuery(conn,"INSERT INTO Cars VALUES(1,'Audi',52642)")
dbSendQuery(conn,"INSERT INTO Cars VALUES(2,'Mercedes',57127)")
dbSendQuery(conn,"INSERT INTO Cars VALUES(3,'Skoda',9000)")
dbSendQuery(conn,"INSERT INTO Cars VALUES(4,'Volvo',29000)")
dbSendQuery(conn,"INSERT INTO Cars VALUES(5,'Bentley',350000)")
dbSendQuery(conn,"INSERT INTO Cars VALUES(6,'Citroen',21000)")
dbSendQuery(conn,"INSERT INTO Cars VALUES(7,'Hummer',41400)")
dbSendQuery(conn,"INSERT INTO Cars VALUES(8,'Volkswagen',21600)")


#dbSendQuery(mydb, 'drop table if exists phases, some_other_table')

#In my experience with this package any SQL query that will run on MySQL will run using this method.



