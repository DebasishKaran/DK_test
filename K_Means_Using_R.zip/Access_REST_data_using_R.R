library(httr)

path <- "http://www.omdbapi.com/?apikey=e380c2d6&type=movie&t=12+Angry+Men&y=1957&plot=full&r=json"

r <- GET(url = path)

status_code(r)

str(content(r))

r <- content(r, as = "text", encoding = "UTF-8")
library(jsonlite)
df <- fromJSON(r,flatten = TRUE)
df
df <- as.data.frame(df)

df_filtered <- df[c(1, 2, 7,9,18)]
df_filtered