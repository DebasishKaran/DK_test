library(ggplot2)
mtcars
# Most basic bar chart
ggplot(mtcars, aes(x = factor(cyl))) +
  geom_bar()

# Change the color of the bars
ggplot(mtcars, aes(x = factor(cyl))) +
  geom_bar(fill = "coral") +
  theme_classic()

# Change intensity
ggplot(mtcars,
       aes(factor(cyl))) +
  geom_bar(fill = "coral",
           alpha = 0.5) +
  theme_classic()

# Color by group
ggplot(mtcars, aes(factor(cyl),
  fill = factor(cyl))) +
  geom_bar()

library(dplyr)
data <- mtcars %>% 
  mutate(am = factor(am, labels = c("auto", "man")),
         cyl = factor(cyl))

ggplot(data, aes(x = cyl, fill = am)) +
  geom_bar() +
  theme_classic()

# Bar chart in percentage
ggplot(data, aes(x = cyl, fill = am)) +
  geom_bar(position = "fill") +
  theme_classic()

# Bar chart side by side
ggplot(data, aes(x = cyl, fill = am)) +
  geom_bar(position = position_dodge()) +
  theme_classic()

data_histogram <- mtcars %>% 
  mutate(cyl = factor(cyl)) %>%
  group_by(cyl)  %>%
  summarize(mean_mpg = round(mean(mpg),2)

            
            
            graph <- ggplot(data_histogram, aes(x = cyl, y = mean_mpg, fill = cyl)) +
    geom_bar(stat = "identity",width = 0.5) +
              coord_flip() +
              theme_classic()

ggplot(df, eas(x= factor(x1)) + geom_bar()