library(dplyr)
PATH <- "https://raw.githubusercontent.com/thomaspernet/data_csv_r/master/data/poisons.csv"
#Step 1
df <- read.csv(PATH) %>%
  #Step 2
  select(-X) %>% 
  #Step 3
  mutate(poison = factor(poison, ordered = TRUE))
glimpse(df)

levels(df$poison)

df %>%
  group_by(poison) %>%
  summarise(
    count_poison = n(),
    mean_time = mean(time, na.rm = TRUE),
    sd_time = sd(time, na.rm = TRUE)
  )
ggplot(df, aes(x = poison, y = time, fill = poison)) +
  geom_boxplot() +
  geom_jitter(shape = 15,
              color = "steelblue",
              position = position_jitter(0.21)) +
  theme_classic()

anova_one_way <- aov(time~poison, data = df)
summary(anova_one_way)

TukeyHSD(anova_one_way)

anova_two_way <- aov(time~poison + treat, data = df)
summary(anova_two_way)