## Load data
# install.packages('mlbench')
data(BreastCancer, package="mlbench")

# keep complete rows
bc <- BreastCancer[complete.cases(BreastCancer), ]

# remove id column
bc <- bc[,-1]

# convert to numeric
for(i in 1:9)
{
 bc[,i] <- as.numeric(as.character(bc[,i]))
}

# Change Y values to 1's and 0's
bc$Class <- ifelse(bc$Class == "malignant",1,0)
# Change Y to factor
bc$Class <- factor(bc$Class, levels=c(0,1))

# Prep Training and Test data.
library(caret)
# define 'not in' func
'%ni%' <- Negate('%in%')
# prevents printing scientific notations
options(scipen=999)  

set.seed(100)

# prepare train and test data
trainDataIndex <- createDataPartition(bc$Class, p = 0.7, list = F)
trainData <- bc[trainDataIndex, ]
testData <- bc[-trainDataIndex, ]

# Class distribution of train data
table(trainData$Class) #1=168,0=311

# Down Sample
set.seed(100)
down_train <- downSample(x=trainData[, colnames(trainData) %ni% "Class"],y=trainData$Class)
table(down_train$Class)

#Up sample
set.seed(100)
up_train <- upSample(x=trainData[, colnames(trainData) %ni% "Class"],y=trainData$Class)
table(up_train$Class)

#Build Logistic Model
logitmod <- glm(Class ~ Cl.thickness + Cell.size + Cell.shape, family = "binomial", data=down_train)
summary(logitmod)

#Perform prediction
pred <- predict(logitmod,newdata = testData, type="response")


# Recode factors
y_pred_num <- ifelse(pred > 0.5, 1,0)
y_pred <- factor(y_pred_num, levels = c(0,1))
y_act  <- testData$Class

#Accuracy Check and found to be 0.9558824
mean(y_pred == y_act)









