import Cat from '../models/study';
import BaseCtrl from './base';

export default class StudyCtrl extends BaseCtrl {
  model = Study;
}
