import * as express from 'express';

import CatCtrl from './controllers/study';
import UserCtrl from './controllers/user';
import Study from './models/study';
import User from './models/user';

export default function setRoutes(app) {

  const router = express.Router();

  const studyCtrl = new StudyCtrl();
  const userCtrl = new UserCtrl();

  // Studies
  router.route('/study').get(studyCtrl.getAll);
  router.route('/studies/count').get(studyCtrl.count);
  router.route('/study').post(studyCtrl.insert);
  router.route('/study/:id').get(studyCtrl.get);
  router.route('/study/:id').put(studyCtrl.update);
  router.route('/study/:id').delete(studyCtrl.delete);

  // Users
  router.route('/login').post(userCtrl.login);
  router.route('/users').get(userCtrl.getAll);
  router.route('/users/count').get(userCtrl.count);
  router.route('/user').post(userCtrl.insert);
  router.route('/user/:id').get(userCtrl.get);
  router.route('/user/:id').put(userCtrl.update);
  router.route('/user/:id').delete(userCtrl.delete);

  // Apply the routes to our application with the prefix /api
  app.use('/api', router);

}
