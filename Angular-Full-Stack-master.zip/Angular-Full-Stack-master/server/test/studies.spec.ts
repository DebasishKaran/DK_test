import * as chai from 'chai';
import * as chaiHttp from 'chai-http';

process.env.NODE_ENV = 'test';
import { app } from '../app';
import Study from '../models/study';

const should = chai.use(chaiHttp).should();

describe('Studies', () => {

  beforeEach(done => {
    Study.remove({}, err => {
      done();
    });
  });

  describe('Backend tests for studies', () => {

    it('should get all the studies', done => {
      chai.request(app)
        .get('/api/studies')
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('array');
          res.body.length.should.be.eql(0);
          done();
        });
    });

    it('should get studies count', done => {
      chai.request(app)
        .get('/api/studies/count')
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('number');
          res.body.should.be.eql(0);
          done();
        });
    });

    it('should create new study', done => {
      const study = new Study({ studyname: 'Study1', projectname: 'Project1', puid: 'ss' });
      chai.request(app)
        .post('/api/study')
        .send(study)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('object');
          res.body.should.have.a.property('studyname');
          res.body.should.have.a.property('projectname');
          res.body.should.have.a.property('puid');
          done();
        });
    });

    it('should get a study by its id', done => {
      const study = new Study({ studyname: 'Study1', projectname: 'Project1', puid: 'ss' });
      study.save((error, newStudy) => {
        chai.request(app)
          .get(`/api/study/${newStudy.id}`)
          .end((err, res) => {
            res.should.have.status(200);
            res.body.should.be.a('object');
             res.body.should.have.a.property('studyname');
          res.body.should.have.a.property('projectname');
          res.body.should.have.a.property('puid');
            res.body.should.have.property('_id').eql(newStudy.id);
            done();
          });
      });
    });

    it('should update a study by its id', done => {
      const study = new Study({ studyname: 'Study1', projectname: 'Project1', puid: 'ss' });
      study.save((error, newStudy) => {
        chai.request(app)
          .put(`/api/study/${newStudy.id}`)
          .send({ projectname: 'ProjectName' })
          .end((err, res) => {
            res.should.have.status(200);
            done();
          });
      });
    });

    it('should delete a study by its id', done => {
      const study = new Study({ studyname: 'Study1', projectname: 'Project1', puid: 'ss' });
      study.save((error, newStudy) => {
        chai.request(app)
          .delete(`/api/study/${newStudy.id}`)
          .end((err, res) => {
            res.should.have.status(200);
            done();
          });
      });
    });
  });

});


