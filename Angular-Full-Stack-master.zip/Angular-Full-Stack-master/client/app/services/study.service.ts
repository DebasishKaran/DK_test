import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

import { Study } from '../shared/models/study.model';

@Injectable()
export class StudyService {

  constructor(private http: HttpClient) { }

  getStudies(): Observable<Study[]> {
    return this.http.get<Study[]>('/api/studies');
  }

  countStudies(): Observable<number> {
    return this.http.get<number>('/api/studies/count');
  }

  addStudies(study: Study): Observable<Study> {
    return this.http.post<Study>('/api/study', study);
  }

  getStudy(study: Study): Observable<Study> {
    return this.http.get<Study>(`/api/study/${study._id}`);
  }

  editStudy(study: Study): Observable<string> {
    return this.http.put(`/api/study/${study._id}`, study, { responseType: 'text' });
  }

  deleteStudy(study: Study): Observable<string> {
    return this.http.delete(`/api/study/${study._id}`, { responseType: 'text' });
  }

}
