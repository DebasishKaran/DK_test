export class Study {
  _id?: string;
  studyname?: string;
  projectname?: string;
  puid?: string;
}
