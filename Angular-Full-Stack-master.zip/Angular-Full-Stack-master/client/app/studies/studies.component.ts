import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { StudyService } from '../services/Study.service';
import { ToastComponent } from '../shared/toast/toast.component';
import { Study } from '../shared/models/Study.model';

@Component({
  selector: 'app-study',
  templateUrl: './study.component.html',
  styleUrls: ['./study.component.scss']
})
export class StudiesComponent implements OnInit {

  Study = new Study();
  study: Study[] = [];
  isLoading = true;
  isEditing = false;

  addStudyForm: FormGroup;
  studyname = new FormControl('', Validators.required);
  projectname = new FormControl('', Validators.required);
  puid = new FormControl('', Validators.required);

  constructor(private studyService: StudyService,
              private formBuilder: FormBuilder,
              public toast: ToastComponent) { }

  ngOnInit() {
    this.getStudies();
    this.addStudyForm = this.formBuilder.group({
      studyname: this.studyname,
      projectname: this.projectname,
      puid: this.puid
    });
  }

  getStudies() {
    this.studyService.getStudies().subscribe(
      data => this.study = data,
      error => console.log(error),
      () => this.isLoading = false
    );
  }

  addStudy() {
    this.studyService.addStudies(this.addStudyForm.value).subscribe(
      res => {
        this.study.push(res);
        this.addStudyForm.reset();
        this.toast.setMessage('item added successfully.', 'success');
      },
      error => console.log(error)
    );
  }

  enableEditing(Study: Study) {
    this.isEditing = true;
    this.Study = Study;
  }

  cancelEditing() {
    this.isEditing = false;
    this.Study = new Study();
    this.toast.setMessage('item editing cancelled.', 'warning');
    // reload the study to reset the editing
    this.getStudies();
  }

  editStudy(Study: Study) {
    this.studyService.editStudy(Study).subscribe(
      () => {
        this.isEditing = false;
        this.Study = Study;
        this.toast.setMessage('item edited successfully.', 'success');
      },
      error => console.log(error)
    );
  }

  deleteStudy(Study: Study) {
    if (window.confirm('Are you sure you want to permanently delete this item?')) {
      this.studyService.deleteStudy(Study).subscribe(
        () => {
          const pos = this.study.map(elem => elem._id).indexOf(Study._id);
          this.study.splice(pos, 1);
          this.toast.setMessage('item deleted successfully.', 'success');
        },
        error => console.log(error)
      );
    }
  }

}
