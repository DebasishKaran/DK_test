export class Employee {
    constructor(
        public _id: string,
        public EmpNo: number,
        public EmpName: string,
        public Salary: number,
        public DeptName: string,
        public Designation: string) { }
}
